"""
Some scripts define objects that we want to import via yaml files
that we pass to the script, so this directory must be a python
module, rather than just a directory full of scripts.
"""
