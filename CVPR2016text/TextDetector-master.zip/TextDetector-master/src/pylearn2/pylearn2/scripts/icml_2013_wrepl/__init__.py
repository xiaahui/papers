"""
Example code for the ICML 2013 Workshop on Representation Learning
"""
