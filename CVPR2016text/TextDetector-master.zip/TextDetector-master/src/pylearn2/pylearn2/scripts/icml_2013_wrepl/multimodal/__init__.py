"""
Example code for the multimodal learning challenge
"""
