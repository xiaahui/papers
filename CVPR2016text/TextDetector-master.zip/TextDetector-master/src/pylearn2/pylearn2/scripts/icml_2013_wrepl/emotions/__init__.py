"""
Example code for the emotion recognition challenge
"""
