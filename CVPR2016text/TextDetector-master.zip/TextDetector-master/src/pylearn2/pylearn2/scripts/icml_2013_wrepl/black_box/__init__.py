"""
Example code for the black box challenge
"""
