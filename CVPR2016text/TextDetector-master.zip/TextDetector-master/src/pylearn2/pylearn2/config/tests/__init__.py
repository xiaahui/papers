"""Tests for the YAML config system."""
