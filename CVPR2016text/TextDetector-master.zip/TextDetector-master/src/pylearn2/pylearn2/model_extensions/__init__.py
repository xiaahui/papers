"""
Extensions (plugins) for Model classes
"""
