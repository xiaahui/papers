"""
Machine learning models.
"""

from pylearn2.models.model import Model
