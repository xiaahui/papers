"""
No tests for now, but there is an example of use in
pylearn2/scripts/gsn_example.py
"""
