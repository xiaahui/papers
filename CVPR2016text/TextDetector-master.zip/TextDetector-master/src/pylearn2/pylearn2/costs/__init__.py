"""
Cost classes used to represent the objective functions we minimize
during training.
"""
