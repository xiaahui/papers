"""
Sandbox datasets for natural language processing (NLP)
"""
