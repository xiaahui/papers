"""
Sandbox models for natural language processing (NLP)
"""
