"""
Sandbox for developing natural language processing (NLP) tools for
Pylearn2, including datasets and models
"""
