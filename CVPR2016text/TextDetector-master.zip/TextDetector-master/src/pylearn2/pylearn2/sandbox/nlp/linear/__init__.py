"""
Sandbox linear operators for natural language processing (NLP)
"""
