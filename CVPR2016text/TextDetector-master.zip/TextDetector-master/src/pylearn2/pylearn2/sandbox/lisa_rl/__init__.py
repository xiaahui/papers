"""
This module contains code used for the LISA lab's reinforcement learning
reading group. Currently it is *very* sandbox-y... none of us has a real
reinforcement learning background, and this isn't our main research work,
just hacking around to learn.
"""

