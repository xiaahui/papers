__author__ = "Ian Goodfellow"

class Agent(object):
    pass
