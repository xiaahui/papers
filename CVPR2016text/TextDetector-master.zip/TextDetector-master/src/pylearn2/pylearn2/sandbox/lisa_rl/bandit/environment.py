__author__ = "Ian Goodfellow"

class Environment(object):
    pass
