__author__ = "Ian Goodfellow"

"""
Bandit functionality.
"""
