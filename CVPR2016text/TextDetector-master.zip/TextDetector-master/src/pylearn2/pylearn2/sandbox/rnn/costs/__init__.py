"""
Costs specific to the RNN framework.
"""
