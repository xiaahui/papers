"""
Layers specific to the RNN framework. These can be layers with
recurrency, but also MLP layers that have been optimized
for use with sequence-data.
"""
