"""
Utilities for RNN framework
"""
