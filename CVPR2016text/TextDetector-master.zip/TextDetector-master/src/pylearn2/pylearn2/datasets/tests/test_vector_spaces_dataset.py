# Currently this test file does nothing but make sure the module can be
# imported.
from pylearn2.datasets import vector_spaces_dataset
