
def test_mnist_imports():

    from pylearn2.datasets.mnist import MNIST
    MNIST.shut_up_the_syntax_highlighting = 1
